## Download and extract the zip file  
## open the folder in a text editor  
## go to client directory and run these commands "npm i" and "npm start"  
## open another terminal window, go to server and run "npm i" and "npm start"
